A Pen created at CodePen.io. You can find this one at http://codepen.io/akhil_001/pen/zoQdaO.

 Inspired from dribble shot 
https://dribbble.com/shots/2385208-World-Places